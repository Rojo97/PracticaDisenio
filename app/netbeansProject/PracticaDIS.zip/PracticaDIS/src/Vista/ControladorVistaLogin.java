/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Modelo.ModeloLogin;

/**
 *
 * @author super
 */
public class ControladorVistaLogin {
    private VistaLogin vistalogin;
    private ModeloLogin modelo;
    
    
    /**
     * Constructor de el controlador.
     * @param vista la vista que debe controlar.
     */
    public ControladorVistaLogin(VistaLogin vista) {
        vistalogin = vista;
        modelo = new ModeloLogin();
    }

    void salir() {
        System.exit(0);
    }

    void comprobarCredenciales(String DNI, String Contraseña) {
        boolean dni = modelo.compruebaDNI(DNI);
        boolean contraseña = modelo.compruebaContraseña(Contraseña);
        if(dni&&contraseña){
            //Cambiamos de ventana
        }else{
            vistalogin.mostrarError();
        }
    }
    
    
    
    
    
    
}
