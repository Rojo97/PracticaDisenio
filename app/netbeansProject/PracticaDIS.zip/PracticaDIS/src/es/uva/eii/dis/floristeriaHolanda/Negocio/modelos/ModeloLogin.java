/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uva.eii.dis.floristeriaHolanda.Negocio.modelos;

/**
 *
 * @author super
 */
public class ModeloLogin {

    
    //No implementados tienen que acceder a la DB
    public boolean compruebaDNI(String DNI) {
     return false;
    }
    public boolean compruebaContraseña(String Contraseña) {
        return false;
    }
    
}
